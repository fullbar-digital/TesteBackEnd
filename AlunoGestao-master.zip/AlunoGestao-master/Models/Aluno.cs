namespace AlunoGestao.Models;

public class Aluno
{
    public int Id { get; set; }
    public string? Nome { get; set; }
    public string? RegistroAcademico { get; set; }

     public int Periodo { get; set; }

     public string? Curso { get; set; }

     public string? Status { get; set; }






}